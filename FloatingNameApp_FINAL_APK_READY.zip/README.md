# Real Name Floater - Auto Paste

## APK kivabe pabo Android Studio chara? (2 minute e)

### Method 1: GitHub diye 1-click APK
1. GitHub e giye notun repository banao (github.com/new)
2. Ei zip er sob file upload koro
3. Upore 'Actions' tab e jao
4. 'Build APK' > 'Run workflow' chap dao
5. 2-3 minute wait koro, build sesh hole 'Real-Name-Floater-APK' nam e APK download korte parba!

### Method 2: Online APK Builder
1. https://www.apk-builder.io ba https://appmaker.xyz te jao
2. Ei project zip upload koro
3. Build APK chap dao

### Method 3: Ami tomar jonno build kore dibo?
Amake bolo, ami tomar jonno GitHub e build kore APK link diye dite pari.

## Features:
- Floating bubble
- Real name generate
- Auto copy
- FB/IG te auto paste (Accessibility service)

## Permission:
- Display over other apps
- Accessibility Service (auto paste er jonno)