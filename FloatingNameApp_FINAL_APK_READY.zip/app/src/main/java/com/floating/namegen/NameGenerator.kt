package com.floating.namegen

import kotlin.random.Random

object NameGenerator {
    private val firstNames = listOf(
        "Aarav", "Rahim", "Karim", "Sakib", "Tamim", "Fahim", "Naim", "Rafi", "Zidan", "Arman",
        "Alex", "John", "David", "Leo", "Max", "Ryan", "Sam", "Ethan", "Noah", "Liam",
        "Anika", "Sara", "Nusrat", "Mim", "Jui", "Tisha", "Riya", "Ayesha", "Fatima", "Zara",
        "Shadow", "Ninja", "Pro", "Ultra", "X", "Ghost", "Fury", "Blaze"
    )
    private val lastNames = listOf(
        "Khan", "Ahmed", "Hossain", "Islam", "Rahman", "Chowdhury", "Gamer", "YT", "Gaming",
        "OP", "Boss", "Legend", "King", "Queen", "99", "77", "X", "ProMax", "Official", "BD"
    )
    private val styles = listOf(
        { f: String, l: String -> "$f $l" },
        { f: String, l: String -> "${f}_${l}" },
        { f: String, l: String -> "${f}${l}${Random.nextInt(10, 999)}" },
        { f: String, l: String -> "${f}.${l}" },
        { f: String, l: String -> "I_am_${f}${l}" },
        { f: String, l: String -> "${f} ${l} YT" }
    )

    fun generate(): String {
        val first = firstNames.random()
        val last = lastNames.random()
        val style = styles.random()
        return style(first, last)
    }
}