package com.floating.namegen

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class AutoPasteAccessibilityService : AccessibilityService() {

    private lateinit var prefs: SharedPreferences

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("floater_prefs", Context.MODE_PRIVATE)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val shouldAutoPaste = prefs.getBoolean("auto_paste_enabled", false)
        val currentName = prefs.getString("current_name", "") ?: ""
        val targetApp = prefs.getString("target_app", "") // fb or ig

        if (!shouldAutoPaste || currentName.isEmpty()) return

        // Only work on FB / IG packages
        val packageName = event.packageName?.toString() ?: return
        if (packageName != "com.facebook.katana" && 
            packageName != "com.facebook.lite" && 
            packageName != "com.instagram.android") return

        // We got event from target, try to auto paste
        // Add small delay
        android.os.Handler(mainLooper).postDelayed({
            tryAutoPaste(currentName, packageName, targetApp)
        }, 800)
    }

    private fun tryAutoPaste(name: String, packageName: String, targetApp: String?) {
        val root = rootInActiveWindow ?: return

        // Strategy 1: Find focused EditText and paste
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (focused != null && focused.className?.contains("EditText") == true) {
            pasteToNode(focused, name)
            return
        }

        // Strategy 2: Find EditText by ID / hint (FB and IG specific)
        val editTexts = mutableListOf<AccessibilityNodeInfo>()
        findAllEditTexts(root, editTexts)

        if (editTexts.isNotEmpty()) {
            // For FB: usually first EditText is First Name, second is Last Name
            // For IG: usually the name field
            // We paste to the focused or first suitable one
            val targetNode = editTexts.firstOrNull { it.isFocused } ?: editTexts.firstOrNull()
            targetNode?.let { pasteToNode(it, name) }
        }
    }

    private fun findAllEditTexts(node: AccessibilityNodeInfo, list: MutableList<AccessibilityNodeInfo>) {
        if (node.className?.toString()?.contains("EditText") == true) {
            list.add(node)
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findAllEditTexts(child, list)
        }
    }

    private fun pasteToNode(node: AccessibilityNodeInfo, text: String) {
        try {
            // Method 1: ACTION_SET_TEXT (Android 5.0+)
            val args = Bundle()
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            val success = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)

            if (success) {
                Toast.makeText(this, "Auto Pasted: $text", Toast.LENGTH_SHORT).show()
                // Disable after successful paste to avoid loop
                prefs.edit().putBoolean("auto_paste_enabled", false).apply()
                Log.d("AutoPaste", "Success pasted $text")
            } else {
                // Fallback: clipboard + ACTION_PASTE
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("name", text))
                node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                android.os.Handler(mainLooper).postDelayed({
                    node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
                    Toast.makeText(this, "Auto Pasted: $text", Toast.LENGTH_SHORT).show()
                    prefs.edit().putBoolean("auto_paste_enabled", false).apply()
                }, 200)
            }
        } catch (e: Exception) {
            Log.e("AutoPaste", "Error: ${e.message}")
        }
    }

    override fun onInterrupt() {}

    override fun onServiceConnected() {
        super.onServiceConnected()
        Toast.makeText(this, "Auto-Paste Service ON - Ekhon FB/IG te auto paste hobe", Toast.LENGTH_LONG).show()
    }
}