package com.floating.namegen

import kotlin.random.Random

object NameGenerator {
    // Real Bangladeshi / International real names
    private val firstNames = listOf(
        "Md. Rahim", "Karim", "Sakib Al", "Tamim", "Fahim", "Arman", "Rafi", "Naim", "Sajid", "Tanvir",
        "Abdullah", "Ahmad", "Rahman", "Hasan", "Hossain", "Anika", "Sara", "Nusrat Jahan", "Ayesha",
        "Fatima", "Zara", "Riya", "Mim", "Jannatul", "Tasnim", "Sumaiya", "John", "David", "Alex", "Michael"
    )
    private val lastNames = listOf(
        "Ahmed", "Khan", "Islam", "Hossain", "Rahman", "Chowdhury", "Uddin", "Hasan", "Ali", "Mahmud",
        "Siddique", "Sarker", "Mollah", "Patwary", "Akter", "Begum", "Smith", "Johnson", "Williams", "Brown"
    )

    fun generate(): String {
        val first = firstNames.random()
        val last = lastNames.random()
        // Real name style: First + Last, avoid numbers
        return "$first $last".replace("  ", " ").trim()
    }

    fun generateWithVariations(): List<String> {
        // 3 variations for user to choose
        return List(3) { generate() }
    }
}