package com.floating.namegen

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val OVERLAY_REQ = 1234
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnStart = findViewById<Button>(R.id.btnStart)
        val btnStop = findViewById<Button>(R.id.btnStop)
        val btnAccess = findViewById<Button>(R.id.btnAccessibility)
        val status = findViewById<TextView>(R.id.txtStatus)

        btnStart.setOnClickListener {
            if (checkOverlayPermission()) {
                startFloatingService()
                status.text = "Floating ON - Ekhon Accessibility ON koro auto-paste er jonno"
            }
        }
        btnStop.setOnClickListener {
            stopService(Intent(this, FloatingService::class.java))
            status.text = "Floating OFF"
        }

        btnAccess.setOnClickListener {
            openAccessibilitySettings()
        }
    }

    private fun checkOverlayPermission(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                startActivityForResult(intent, OVERLAY_REQ)
                Toast.makeText(this, "Floating permission dao", Toast.LENGTH_LONG).show()
                return false
            }
        }
        return true
    }

    private fun openAccessibilitySettings() {
        try {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            startActivity(intent)
            Toast.makeText(this, "List theke 'Real Name Floater' khuje ON koro", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Settings khulte parini", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startFloatingService() {
        val intent = Intent(this, FloatingService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        Toast.makeText(this, "Floating Icon chalu!", Toast.LENGTH_SHORT).show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == OVERLAY_REQ) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) {
                startFloatingService()
            }
        }
    }
}