package com.floating.namegen

import android.app.*
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat

class FloatingService : Service() {

    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private var params: WindowManager.LayoutParams? = null
    private var currentName = ""
    private lateinit var prefs: SharedPreferences
    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var isMoving = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("floater_prefs", Context.MODE_PRIVATE)
        createNotificationChannel()
        startForeground(1, createNotification())
        showFloatingIcon()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("floating_channel", "Floating Service", NotificationManager.IMPORTANCE_LOW)
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, "floating_channel")
            .setContentTitle("Real Name Auto-Paste Active")
            .setContentText("Tap = new name | FB/IG = auto paste")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentIntent(pendingIntent)
            .build()
    }

    private fun showFloatingIcon() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val inflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        floatingView = inflater.inflate(R.layout.layout_floating, null)

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params!!.gravity = Gravity.TOP or Gravity.START
        params!!.x = 100
        params!!.y = 300

        val icon = floatingView!!.findViewById<View>(R.id.floatingIcon)
        val txtName = floatingView!!.findViewById<TextView>(R.id.txtLastName)
        val actionPanel = floatingView!!.findViewById<LinearLayout>(R.id.actionPanel)
        val btnFB = floatingView!!.findViewById<TextView>(R.id.btnFB)
        val btnIG = floatingView!!.findViewById<TextView>(R.id.btnIG)

        currentName = NameGenerator.generate()
        txtName.text = currentName
        saveCurrentName(currentName)

        icon.setOnClickListener {
            if (!isMoving) {
                currentName = NameGenerator.generate()
                txtName.text = currentName
                saveCurrentName(currentName)
                copyToClipboard(currentName)
                actionPanel.visibility = View.VISIBLE
                icon.animate().scaleX(1.2f).scaleY(1.2f).setDuration(120).withEndAction {
                    icon.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                }.start()
            }
        }

        btnFB.setOnClickListener {
            prepareAutoPaste("fb")
            openFacebook()
        }

        btnIG.setOnClickListener {
            prepareAutoPaste("ig")
            openInstagram()
        }

        txtName.setOnClickListener {
            copyToClipboard(currentName)
            actionPanel.visibility = if (actionPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }

        icon.setOnLongClickListener {
            stopSelf()
            Toast.makeText(this, "Floating bondho", Toast.LENGTH_SHORT).show()
            true
        }

        floatingView!!.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    isMoving = false
                    initialX = params!!.x
                    initialY = params!!.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (kotlin.math.abs(dx) > 10 || kotlin.math.abs(dy) > 10) isMoving = true
                    params!!.x = initialX + dx
                    params!!.y = initialY + dy
                    windowManager!!.updateViewLayout(floatingView, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    v.postDelayed({ isMoving = false }, 100)
                    true
                }
                else -> false
            }
        }

        windowManager!!.addView(floatingView, params)
    }

    private fun saveCurrentName(name: String) {
        prefs.edit().putString("current_name", name).apply()
    }

    private fun prepareAutoPaste(target: String) {
        prefs.edit()
            .putString("current_name", currentName)
            .putString("target_app", target)
            .putBoolean("auto_paste_enabled", true)
            .apply()
        copyToClipboard(currentName)
    }

    private fun copyToClipboard(text: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Real Name", text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(this, "Copied: $text", Toast.LENGTH_SHORT).show()
    }

    private fun openFacebook() {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://m.facebook.com/settings/"))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            Toast.makeText(this, "FB khulche... Name field e tap koro, auto paste hobe!", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "FB open korte problem", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openInstagram() {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/accounts/edit/"))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            // Try IG app first
            try { intent.setPackage("com.instagram.android") } catch (e: Exception) {}
            startActivity(intent)
            Toast.makeText(this, "IG khulche... Name field e tap koro, auto paste hobe!", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "IG open korte problem", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        floatingView?.let { windowManager?.removeView(it) }
    }
}